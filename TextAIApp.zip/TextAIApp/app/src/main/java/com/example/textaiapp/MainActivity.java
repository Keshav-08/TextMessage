package com.example.textaiapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    BroadcastReceiverClass receiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        receiver = new BroadcastReceiverClass();
        IntentFilter i = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(receiver, i);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_DENIED || ActivityCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED ) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.RECEIVE_SMS, android.Manifest.permission.SEND_SMS}, 0);
        }

    }

}

